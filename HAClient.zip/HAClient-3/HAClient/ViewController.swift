
//  ViewController.swift
//  myFirstApp
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var hm1: UIImageView!
    
    let client:TCPClient = TCPClient(addr: "192.168.0.100", port: 27014)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tcpclient(status: "Connected")
        
        let newImg: UIImage? = UIImage(named: "image4.jpg")
        self.hm1.image = newImg
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    

    
    
    // Update here
    
    @IBOutlet weak var RedSwitch: UISwitch!
    @IBOutlet weak var GreenSwitch: UISwitch!
    @IBOutlet weak var BlueSwitch: UISwitch!
    @IBOutlet weak var WhiteSwitch: UISwitch!
    @IBOutlet weak var YellowSwitch: UISwitch!
    @IBOutlet weak var RandomSwitch: UISwitch!
    
    @IBAction func connectBtn(_ sender: Any) {
        
        client.close()
        print("Connection Closed")
    }
    var status = ""
    
    
    //The function lights the RED LED which is connected to Pin D0
    @IBAction func redSwitch(_ switch: UISwitch) {
        if(RedSwitch.isOn){
            var (success,errmsg)=client.send(str:"R" )
            if success{
                print("Red LED is On");
            } else {
                print("Please check your connection")
            }
            
        }else{
            var (success,errmsg)=client.send(str:"r" )
            if success{
                print("Red LED is Off");
            } else {
                print("something went wrong")
            }
            
        }
        
    }
    
    //The function lights the GREEN LED which is connected to Pin D2
    @IBAction func greenSwitch(_ switch: UISwitch)
    {
        if(GreenSwitch.isOn){
            var (success,errmsg)=client.send(str:"G" )
            if success{
                print("Green LED is On");
            } else {
                print("Please check your connection")
            }
            
        }else{
            var (success,errmsg)=client.send(str:"g" )
            if success{
                print("Green LED is Off");
            } else {
                print("something went wrong")
            }

        }
    }
    
    
    //The function lights the BLUE LED which is connected to Pin D1
    @IBAction func blueSwitch(_ switch: UISwitch)
    {
        if(BlueSwitch.isOn){
            var (success,errmsg)=client.send(str:"B" )
            if success{
                print("Blue LED is On");
            } else {
                print("Please check your connection")
            }
        }else{
            var (success,errmsg)=client.send(str:"b" )
            if success{
                print("Blue LED is Off");
            } else {
                print("something went wrong")
            }
        }
    }
    
    //The function lights the WHITE LED which is connected to Pin D5
    @IBAction func whiteSwitch(_ switch: UISwitch)
    {
        if(WhiteSwitch.isOn){
            var (success,errmsg)=client.send(str:"W" )
            if success{
                print("White LED is On");
            } else {
                print("Please check your connection")
            }
        }else{
            var (success,errmsg)=client.send(str:"w" )
            if success{
                print("White LED is Off");
            } else {
                print("something went wrong")
            }
        }
    }
    
    //The function lights the YELLOW LED which is connected to Pin D7
    @IBAction func yellowSwitch(_ switch: UISwitch){
        if(YellowSwitch.isOn){
            var (success,errmsg)=client.send(str:"Y" )
            if success{
                print("Yellow LED is On");
            } else {
                print("Please check your connection")
            }
        }else{
            var (success,errmsg)=client.send(str:"y" )
            if success{
                print("Yellow LED is Off");
            } else {
                print("something went wrong")
            }
        }
    }
    
    //The function lights the LED in a random manner
    @IBAction func randomSwitch(_ switch: UISwitch) {
        if(RandomSwitch.isOn){
            var (success,errmsg)=client.send(str:"O" )
            if success{
                print("LEDs will light randomly");
            } else {
                print("Please check your connection")
            }
        }else{
            var (success,errmsg)=client.send(str:"o" )
            if success{
                print("All LEDs turned Off");
            } else {
                print("something went wrong")
            }
        }
    }
    
    // End update
    
    //The client side code which connects to the server using TCP
    func tcpclient(status:String){
        var (success,errmsg)=client.connect(timeout: 1)
        if success{
            var (success,errmsg)=client.send(str:status )
            
            print("sent status")
        }else{
            print(errmsg)
        }
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

